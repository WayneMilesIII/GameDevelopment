﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Basic : MonoBehaviour
{

    public float moveSpeed = 1f;

    private int health;

    public Transform player;

    public Rigidbody2D rb;

    Vector2 movement;
    Vector2 moveDirection;
    float lookAngle;
    
    // Start is called before the first frame update
    void Start()
    {
        rb = this.GetComponent<Rigidbody2D>();
        health = 3;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollision2D(Collision2D col) 
    {
        
    }
}
