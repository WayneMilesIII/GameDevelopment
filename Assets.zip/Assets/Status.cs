using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Status : MonoBehaviour
{
    // init variables
    private int health = 100, score = 0, ammo = 64, lives = 3;
    public Text healthState, scoreState, ammoState, livesCount;

    // Update is called once per frame
    void Update()
    {
        healthState.text = "HEALTH: " + health;
        ammoState.text = "AMMO: " + ammo;
        scoreState.text = "SCORE: " + score;
        livesCount.text = "LIVES: " + lives;
    }
    
    // setter methods
    public  void setHealth(int h)
    {
        this.health = h; 
    }

    public  void setAmmo(int a)
    {
        this.ammo = a;
    }

    public  void setScore(int s)
    {
        this.score = s;
    }

    public  void setLives(int l)
    {
        this.lives = l;
    }
}
