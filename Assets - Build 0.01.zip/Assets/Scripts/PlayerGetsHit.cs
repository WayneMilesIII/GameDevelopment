﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGetsHit : MonoBehaviour
{

    public static int playerHealth;

    // Start is called before the first frame update
    void Start()
    {
        playerHealth = 100;
        Status.playerLives = 5;
    }

    void OnCollisionEnter2D(Collision2D col) 
    {
        if (col.gameObject.tag.Equals("Enemy")) 
        {
            playerHealth -= 10;
            //DO SOMETHING MAKE ENEMY NOT ON PLAYER ANYMORE
        }
    }


    // Update is called once per frame
    void Update()
    {
        if (playerHealth <= 0) 
        {
            playerHealth += 100;
            Status.playerLives -= 1;
        }

        if (Status.playerLives == 0) 
        { 
            //PUT SOMETHING HERE TO GIVE GAME OVER.
        }
    }
}
