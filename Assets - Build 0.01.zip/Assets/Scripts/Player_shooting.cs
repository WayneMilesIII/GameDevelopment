﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_shooting : MonoBehaviour
{

    public Transform Projectile_Spawner;
    public GameObject projTemplate;

    public float projForce = 20f;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) 
        {
            Shoot();
        }
    }

    void Shoot() 
    {
        GameObject projectile = Instantiate(projTemplate, Projectile_Spawner.position, Projectile_Spawner.rotation);
        Rigidbody2D rb = projectile.GetComponent<Rigidbody2D>();
        rb.AddForce(Projectile_Spawner.up * projForce, ForceMode2D.Impulse);
    }

}
