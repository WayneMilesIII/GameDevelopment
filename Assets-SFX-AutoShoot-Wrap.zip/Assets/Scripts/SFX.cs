using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SFX : MonoBehaviour
{
	// init variables
	public AudioSource pew;
	public AudioSource boom;

	/*
	void start(){
		 pew = gameObject.AddComponent<AudioSource>();
		 pew.clip = Resources.Load("PewSFX.mp3") as AudioClip;
		 //audioSource.Play();
	}
	*/
	/*
	void Update()
    {
        if ( Input.GetMouseButtonDown(0) ){ // && !(PauseMenu.GameIsPaused) 
        	//
        	pew.Play(); 
        }
    }
	*/
    /*
	void OnMouseDown(){
		pew.Play();
	}*/

    public void PlayPew()
    {
        pew.Play(); 
    }
    public void PlayBoom()
    {
        boom.Play(); 
    }
}
